function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
function load_game(game_name) {
	if (game_name === 'blackjack') {
		$("#game_loads_here").load("includes/games/blackjack.html");
	}
	if (game_name === 'minesweeper') {
		$("#game_loads_here").load("includes/games/minesweeper/index.html");
	}
}
function startToggleInit() {
	let player = getCookie('player');
   	document.getElementById('choose_game').innerHTML = player + '<br>Please Choose a Game';
	document.getElementById('quit_game').style.display = 'none';
	document.getElementById('choose_game').style.display = 'inline-block';
	document.getElementById('game_selection').style.display = 'flex';
}
function startToggle() {
	document.getElementById('choose_game').style.display = 'none';
	document.getElementById('game_selection').style.display = 'none';
	document.getElementById('quit_game').style.display = 'block';
}
function quit_game() {
	$('#game_loads_here').empty( $('canvas#defaultCanvas0') );
	$("#game_loads_here").html('<img src="assets/img/splash-screen.jpg" />');
}
function quitToggle() {
	document.getElementById('quit_game').style.display = 'none';
	document.getElementById('choose_game').style.display = 'inline-block';
	document.getElementById('game_selection').style.display = 'flex';
}
// form action
$(document).ready(function() {
  $('form#gameNameCreate').on('submit', function(e){
    e.preventDefault();
    var name = $('#username').val();
    if(name == ''){
     $('.message_box').html('<span style="color:red;">Enter Your Name!</span>');
     $('#username').focus();
     return false;
   } else {
 
   $.ajax({
    type: "POST",
    url: '../../uat_game_app/includes/create_gamer.php',
    data: "username="+name,
    success: function(data) {
   	 document.getElementById('gameNameCreate').style.display = 'none';
    },
    complete: function(data){
   	 startToggleInit();
    }
   });
  }
 }); // submit form

});