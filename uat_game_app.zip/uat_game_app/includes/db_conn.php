<?php 
class Database extends PDO
{
    private $host   = 'localhost:8889';
    private $user   = 'root';
    private $pass   = 'root';
    private $dbname = 'uat_game_app';

    public function __construct($dsn = null, $user = null, $pass = null, $opts = null)
    {
        parent::__construct(
            "mysql:host={$this->host};dbname={$this->dbname}",
            $this->user,
            $this->pass,
            $opts
        );
        $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
}