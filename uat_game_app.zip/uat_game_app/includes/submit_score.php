<?php
// this is not working yet

require_once 'db_conn.php';
require_once 'classes.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name = $_POST['username'];
	if (!empty($name)) {
		$db = new Database();
		$username = new Scores($db);
		$username->create($name);
	}
}