<h1 class="text-center">UAT Multi-Game App</h1>
<p class="text-center">UAT &copy; <?php echo date("Y"); ?></p>
